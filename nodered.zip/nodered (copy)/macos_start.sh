#!/bin/bash
chmod -R +x node_modules/node-red/
node node_modules/node-red/red.js --userDir ./data